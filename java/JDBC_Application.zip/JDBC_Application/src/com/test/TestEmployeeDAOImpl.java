package com.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dao.EmployeeDAO;
import com.dao.EmployeeDAOImpl;
import com.pojo.Employee;

public class TestEmployeeDAOImpl {

	EmployeeDAO dao;
	
	@Before
	public void setUp() throws Exception {
		dao = new EmployeeDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testAddEmployee_positive() {
		
		Employee employee = new Employee(1,1000, "CDK", "JAVA");
		int added = dao.addEmployee(employee);
		assertTrue(added == 1);
		
		
		
	}

	@Test
	public void testAddEmployee1() {
		
	}

	@Test
	public void testUpdateEmployee() {
		
	}

	@Test
	public void testDeleteEmployee() {
		
	}

	@Test
	public void testFindEmployeeById() {
		
	}

	@Test
	public void testFindAllEMployees() {
		
	}

}
